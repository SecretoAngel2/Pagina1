
var listaDeGente = [
    ["Adrià Julián", 1, "Adrià", "Julián", "1", 170, "17", "Overcooked 2", "PC"],
    ["Ainhoa Ortega", 2, "Ainhoa", "Ortega", "4", 160, "17", "The Sims 4", "PC"],
    ["Alex Gutiérrez", 3, "Alex", "Gutiérrez", "1", 182, "16", "Minecraft", "PC"],
    ["Aleix Guillén", 4, "Aleix", "Guillén", "2", 177, "17", "Metal Gear Solid", "PC"],
    ["Alan Espadas", 5, "Alan", "Espadas", "3", 167, "16", "Portal 2", "PC"],
    ["Antonio Alaminos", 6, "Antonio", "Alaminos", "2", 170, "16", "Action Taimanin", "PC"],
    ["Arnau Bel", 7, "Arnau", "Bel", "3", 182, "17", "Minecraft", "PC"],
    ["Daniel Romero", 8, "Daniel", "Romero", "1", 173, "16", "Valorant", "PC"],
    ["David Gallardo", 9, "David", "Gallardo", "1", 183, "17", "Skyrim", "PC"],
    ["Héctor Ortiz", 10, "Héctor", "Ortiz", "4", 180, "16", "Dragon Ball Xenoverse 2", "PS"],
    ["Iker Pérez", 11, "Iker", "Pérez", "2", "-", "-", "-", "Consola"],
    ["Jan Lucas", 12, "Jan", "Lucas", "2", 185, "16", "Valorant", "PC"],
    ["Joan Fernández", 13, "Joan", "Fernández", "4", 176, "17", "Pou", "Consola"],
    ["Joel García", 14, "Joel", "García", "1", 184, "17", "Minecraft", "PC"],
    ["Joel Martín", 15, "Joel", "Martín", "3", 168, "16", "Fifa", "PS"],
    ["Joel Sastre", 16, "Joel", "Sastre", "3", 182, "16", "League of Legends", "PC"],
    ["Pol Gallardo", 17, "Pol", "Gallardo", "3", 176, "16", "WWE Supercard", "PC"]
];

var primerItem = false;
var antiDupe = false;
var numeroAleatorio = Math.floor(Math.random() * 16) + 1;
var personaRandom = listaDeGente[numeroAleatorio-1]
function agregarname() {
    var nameInput = document.getElementById("nameInput").value;
    var nameList = document.getElementById("nameList");
    var cabeceraEntero = document.getElementById("itemCabecera");

    for (var i = 0; i < listaDeGente.length; i++) {
        if (listaDeGente[i][0] == nameInput){
            if (nameInput) {
                var listItem = document.createElement("div");
                listItem.classList.add("listaPersonas");
                nameList.appendChild(listItem);

                var listItem1 = document.createElement("div");
                var listItem2 = document.createElement("div");
                var listItem3 = document.createElement("div");
                var listItem4 = document.createElement("div");
                var listItem5 = document.createElement("div");
                var listItem6 = document.createElement("div");
                var listItem7 = document.createElement("div");
                if (listaDeGente[i][2] == personaRandom[2]) {listItem7.classList.add("datoPersona");} else {listItem7.classList.add("datoPersona2");}
                if (listaDeGente[i][3] == personaRandom[3]) {listItem6.classList.add("datoPersona");} else {listItem6.classList.add("datoPersona2");}
                if (listaDeGente[i][4] == personaRandom[4]) {listItem5.classList.add("datoPersona");} else {listItem5.classList.add("datoPersona2");}
                if (listaDeGente[i][5] == personaRandom[5]) {listItem4.classList.add("datoPersona");} else {listItem4.classList.add("datoPersona2");}
                if (listaDeGente[i][6] == personaRandom[6]) {listItem3.classList.add("datoPersona");} else {listItem3.classList.add("datoPersona2");}
                if (listaDeGente[i][7] == personaRandom[7]) {listItem2.classList.add("datoPersona");} else {listItem2.classList.add("datoPersona2");}
                if (listaDeGente[i][8] == personaRandom[8]) {listItem1.classList.add("datoPersona");} else {listItem1.classList.add("datoPersona2");}
                listItem7.textContent = listaDeGente[i][2];
                listItem6.textContent = listaDeGente[i][3];
                listItem5.textContent = listaDeGente[i][4];
                if (listaDeGente[i][5] > personaRandom[5]) {listItem4.textContent = listaDeGente[i][5]+" ⬇️";}
                if (listaDeGente[i][5] == personaRandom[5]) {listItem4.textContent = listaDeGente[i][5]}
                if (listaDeGente[i][5] < personaRandom[5]) {listItem4.textContent = listaDeGente[i][5]+" ⬆️";}
                listItem3.textContent = listaDeGente[i][6];
                listItem2.textContent = listaDeGente[i][7];
                listItem1.textContent = listaDeGente[i][8];
                if (!antiDupe) {
                    listItem.insertBefore(listItem1, listItem.firstChild);
                    listItem.insertBefore(listItem2, listItem.firstChild);
                    listItem.insertBefore(listItem3, listItem.firstChild);
                    listItem.insertBefore(listItem4, listItem.firstChild);
                    listItem.insertBefore(listItem5, listItem.firstChild);
                    listItem.insertBefore(listItem6, listItem.firstChild);
                    listItem.insertBefore(listItem7, listItem.firstChild);
                    antiDupe = true;
                }
                // Limpiar campo de texto después de agregar el name
                document.getElementById("nameInput").value = '';

                if (!primerItem){
                    primerItem = true;
                    var categoriaCabecera1 = document.createElement("div");
                    var categoriaCabecera2 = document.createElement("div");
                    var categoriaCabecera3 = document.createElement("div");
                    var categoriaCabecera4 = document.createElement("div");
                    var categoriaCabecera5 = document.createElement("div");
                    var categoriaCabecera6 = document.createElement("div");
                    var categoriaCabecera7 = document.createElement("div");
                    categoriaCabecera1.classList.add("categoriaCabecera");
                    categoriaCabecera2.classList.add("categoriaCabecera");
                    categoriaCabecera3.classList.add("categoriaCabecera");
                    categoriaCabecera4.classList.add("categoriaCabecera");
                    categoriaCabecera5.classList.add("categoriaCabecera");
                    categoriaCabecera6.classList.add("categoriaCabecera");
                    categoriaCabecera7.classList.add("categoriaCabecera");
                    categoriaCabecera1.textContent = "Name";
                    categoriaCabecera2.textContent = "Surname";
                    categoriaCabecera3.textContent = "Row";
                    categoriaCabecera4.textContent = "Height";
                    categoriaCabecera5.textContent = "Age";
                    categoriaCabecera6.textContent = "Fav Game";
                    categoriaCabecera7.textContent = "Fav Platform";
                    cabeceraEntero.appendChild(categoriaCabecera1);
                    cabeceraEntero.appendChild(categoriaCabecera2);
                    cabeceraEntero.appendChild(categoriaCabecera3);
                    cabeceraEntero.appendChild(categoriaCabecera4);
                    cabeceraEntero.appendChild(categoriaCabecera5);
                    cabeceraEntero.appendChild(categoriaCabecera6);
                    cabeceraEntero.appendChild(categoriaCabecera7);
                }
            }
        }
    }
}

// Filtrar opciones de la lista desplegable según lo escrito en el campo de texto
document.getElementById("nameInput").addEventListener("input", function() {
    var nameInput = this.value.toLowerCase();
    var nameDropdown = document.getElementById("nameDropdown");
    var options = nameDropdown.getElementsByTagName("option");

    // Mostrar solo las opciones que coinciden con lo escrito
    for (var i = 0; i < options.length; i++) {
        var option = options[i];
        if (option.value.toLowerCase().startsWith(nameInput)) {
            option.style.display = "block";
        } else {
            option.style.display = "none";
        }
    }
    for (var i = 0; i < options.length; i++) {
        var option = options[i];
        if (option.style.display !== "none") {
        nameDropdown.selectedIndex = i;
        break;
        }
    }
});

// Actualizar el campo de texto cuando se selecciona un name en la lista desplegable
document.getElementById("nameDropdown").addEventListener("change", function() {
    antiDupe = false;
    var selectedname = this.value;
    document.getElementById("nameInput").value = selectedname.charAt(0).toUpperCase() + selectedname.slice(1);
});