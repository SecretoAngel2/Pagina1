
let index = 0;
const imagenes = ["noabrir/foto1.jpg", "noabrir/foto2.jpg", "noabrir/foto3.jpg", "noabrir/foto4.jpg", "noabrir/foto5.jpg", "noabrir/foto6.jpg"];
const imagenCarrusel = document.getElementById("imagenCarrusel");

function mostrarMensajeDivertido() {
    alert('Eres la razón de mi felicidad. Te amo, mi amor 😊');
}

function subir(){
    index = (index + 1) % imagenes.length;
    cambiarImagen()
}

function bajar(){
    index = (index - 1) % imagenes.length;
    if (index==-1) {
        index = imagenes.length-1
    }
    cambiarImagen()
}

function cambiarImagen() {
    imagenCarrusel.src = imagenes[index];
}
const icons = ["❤️", "🌹", "🍫", "🍦", "🎈", "🎁", "❤️", "🌹", "🍫", "🍦", "🎈", "🎁"];
let revealedCards = [];
let matchedPairs = 0;
let timeRemaining = 5;
let gameStarted = false;
let preguntaClicked = false;
let timerId;

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

function createCard(icon) {
    const card = document.createElement("div");
    card.className = "card";
    card.textContent = icon;
    card.onclick = () => revealCard(card, icon);
    return card;
}

function revealCard(card, icon) {
    if (gameStarted == true){
    if (card.classList.contains("revealed") || revealedCards.length === 2) {
        return;
    }

    card.classList.add("revealed");
    revealedCards.push({ card, icon });

    if (revealedCards.length === 2) {
        setTimeout(checkMatch, 500);
    }
    }
}

function checkMatch() {
    const [firstCard, secondCard] = revealedCards;

    if (firstCard.icon === secondCard.icon) {
        firstCard.card.classList.add("matched");
        secondCard.card.classList.add("matched");
        matchedPairs++;
        if (matchedPairs === icons.length / 2) {
            document.getElementById("invitation").style.display = "block";
            clearInterval(timerId);
        }
    } else {
        firstCard.card.classList.remove("revealed");
        secondCard.card.classList.remove("revealed");
    }

    revealedCards = [];
}


function initializeGame() {
    shuffleArray(icons);
    const gameContainer = document.getElementById("gameContainer");
    icons.forEach(icon => {
        gameContainer.appendChild(createCard(icon));
    });

}

function startTimer() {
    timeRemaining = 60;
    timerId = setInterval(() => {
        if (timeRemaining <= 0) {
            clearInterval(timerId);
            endGame();
        } else {
            const minutes = String(Math.floor(timeRemaining / 60)).padStart(2, '0');
            const seconds = String(timeRemaining % 60).padStart(2, '0');
            document.getElementById("timer").textContent = `${minutes}:${seconds}`;
            timeRemaining--;
        }
    }, 1000);
}

function endGame() {
    if (matchedPairs !== icons.length / 2) {
        ///document.getElementById("gameContainer").style.display = "none";
        ///document.getElementById("timer").style.display = "none";
        document.getElementById("invitation").innerHTML = "Se ha acabado el tiempo. <br> Inténtalo de nuevo ^^";
        document.getElementById("invitation").style.display = "block";
        gameStarted = false;
        revelarTodasLasCartas();
        document.getElementById("timer").textContent = `00:00`;
        
        
    }
}

function startgame() {
    document.getElementById("invitation").style.display = "none";
    gameStarted = true;
    shuffleArray(icons);
    const cards = document.querySelectorAll('.card');

    cards.forEach(card => {
        card.remove();
    });
    const gameContainer = document.getElementById("gameContainer");
    icons.forEach(icon => {
        gameContainer.appendChild(createCard(icon));
    });
    startTimer()
}
function revelarTodasLasCartas() {
    const todasLasCartas = document.querySelectorAll('.card');

    todasLasCartas.forEach(card => {
        if (!card.classList.contains('revealed') && !card.classList.contains('matched')) {
            card.classList.add('revealed');
        }
    });
}

initializeGame();

function mostrarRespuesta(esSI) {
    if (preguntaClicked == false){
    const respuestaDiv = document.createElement('div');
    respuestaDiv.style.fontSize = '18px';
    respuestaDiv.style.marginTop = '20px';

    if (esSI) {
        respuestaDiv.textContent = 'Oh, muchas gracias amor <3';
      } else {
        respuestaDiv.textContent = '¿Como demonions pulsaste este botón?';
    }

    document.getElementById('cuadrado').appendChild(respuestaDiv);  
    preguntaClicked = true;
    }
  }

  function moverBoton() {
    const noButton = document.getElementById('noButton');
    const cuadrado = document.getElementById('cuadrado');

    // Cambiar la posición del botón "NO"
    const nuevaPosicionX = Math.floor(Math.random() * (cuadrado.clientWidth - noButton.clientWidth));
    const nuevaPosicionY = Math.floor(Math.random() * (cuadrado.clientHeight - noButton.clientHeight));

    noButton.style.position = 'absolute';
    noButton.style.left = nuevaPosicionX + 'px';
    noButton.style.top = nuevaPosicionY + 'px';
  }
  function moverImagen() {
    const image1 = document.getElementById("movingImage1");
    const image2 = document.getElementById("movingImage2");
    const image3 = document.getElementById("movingImage3");
    const image4 = document.getElementById("movingImage4");
    const image5 = document.getElementById("movingImage5");

    // Mostrar la imagen
    image1.style.opacity = 1;
    image2.style.opacity = 1;
    image3.style.opacity = 1;
    image4.style.opacity = 1;
    image5.style.opacity = 1;

    // Aplicar la animación
    image1.style.animation = "moveAndRotate 3s ease-in-out forwards";
    image2.style.animation = "moveAndRotate2 3s ease-in-out forwards";
    image3.style.animation = "moveAndRotate3 3s ease-in-out forwards";
    image4.style.animation = "moveAndRotate4 3s ease-in-out forwards";
    image5.style.animation = "moveAndRotate5 3s ease-in-out forwards";
  }
  function lootear1(){
    const imagen1 = document.getElementById("movingImage1");
    imagen1.style.opacity = 0;
    const imagen2 = document.getElementById("itemhotbar4");
    imagen2.style.opacity = 1;
  }
  function lootear2(){
    const imagen1 = document.getElementById("movingImage2");
    imagen1.style.opacity = 0;
    const imagen2 = document.getElementById("itemhotbar5");
    imagen2.style.opacity = 1;
  }
  function lootear3(){
    const imagen1 = document.getElementById("movingImage3");
    imagen1.style.opacity = 0;
    const imagen2 = document.getElementById("itemhotbar3");
    imagen2.style.opacity = 1;
  }
  function lootear4(){
    const imagen1 = document.getElementById("movingImage4");
    imagen1.style.opacity = 0;
    const imagen2 = document.getElementById("itemhotbar1");
    imagen2.style.opacity = 1;
  }
  function lootear5(){
    const imagen1 = document.getElementById("movingImage5");
    imagen1.style.opacity = 0;
    const imagen2 = document.getElementById("itemhotbar2");
    imagen2.style.opacity = 1;
  }

  const wordList = [
    {
        word: "JIREN",
        hint: "El mas fuerte de DBS"
    },
    {
        word: "BLANCA",
        hint: "Mejor persona usando un subfusil del mundo :0"
    },
    {
        word: "01-de-noviembre",
        hint: "Fecha en la que empezamos a ser novios"
    },
    {
        word: "FORNITE",
        hint: "Tu videojuego favorito"
    },
    {
        word: "ALBONDIGAS-CON-SALSA",
        hint: "Comida"
    },
    {
        word: "ANGEL",
        hint: "Tu inesperado novio"
    },
    {
        word: "ABRAZARTE",
        hint: "Cosa q mas quiero hacer contigo 😏"
    },
    {
        word: "BESO",
        hint: "Otra cosa q mas quiero hacer contigo otra vez 😏😏(Lleva una 'S')"
    }
];
const wordDisplay = document.querySelector(".word-display");
const guessesText = document.querySelector(".guesses-text b");
const keyboardDiv = document.querySelector(".keyboard");
const hangmanImage = document.querySelector(".hangman-box img");
const gameModal = document.querySelector(".game-modal");
const playAgainBtn = gameModal.querySelector("button");


let currentWord, correctLetters, wrongGuessCount;
let palabra = 0;
const maxGuesses = 6;

const resetGame = () => {
    correctLetters = [];
    wrongGuessCount = 0;
    hangmanImage.src = "noabrir/hangman-0.svg";
    guessesText.innerText = `${wrongGuessCount} / ${maxGuesses}`;
    wordDisplay.innerHTML = currentWord.split("").map(() => `<li class="letter"></li>`).join("");
    keyboardDiv.querySelectorAll("button").forEach(btn => btn.disabled = false);
    gameModal.classList.remove("show");
    if (palabra == 7){
    wordDisplay.querySelectorAll("li")[1].innerText = 'e';
    wordDisplay.querySelectorAll("li")[1].classList.add("guessed");
    wordDisplay.querySelectorAll("li")[3].innerText = 'o';
    wordDisplay.querySelectorAll("li")[3].classList.add("guessed");
    correctLetters.push('e');
    correctLetters.push('o');
    }
}

const getRandomWord = () => {

    const { word, hint } = wordList[palabra];
    currentWord = word.toLocaleLowerCase(); 
    document.querySelector(".hint-text b").innerText = hint;
    resetGame();
}

const gameOver = (isVictory) => {
    if (isVictory) {
        palabra++;
        if (palabra == 8){
            palabra = 0
        }
    }
    if (wordList.length > 0) {
        let modalText = isVictory ? `Has encontrado la palabra` : 'Vuelve a intentarlo';
        gameModal.querySelector("img").src = `noabrir/${isVictory ? 'victory' : 'lost'}.gif`;
        gameModal.querySelector("h4").innerText = isVictory ? 'Enhorabuena!' : 'Game Over!';
        gameModal.querySelector("p").innerHTML = `${modalText} `;
        gameModal.classList.add("show");
    }
}

const initGame = (button, clickedLetter) => {
    if (currentWord.includes(clickedLetter)) {
        [...currentWord].forEach((letter, index) => {
            if (letter === clickedLetter) {
                correctLetters.push(letter);
                wordDisplay.querySelectorAll("li")[index].innerText = letter;
                wordDisplay.querySelectorAll("li")[index].classList.add("guessed");
            }
        });
    } else {
        if (palabra == 6){
            if (clickedLetter === 'f') {
                alert("Se puede saber porque has pulsado la 'F' en esta pregunta??? ¡¡ACASO CREES QUE LO QUE MAS QUIERO HACER CONIGO EMPIEZA POR F!!.");
            }
        }
        wrongGuessCount++;
        hangmanImage.src = `noabrir/hangman-${wrongGuessCount}.svg`;
    }
    button.disabled = true;
    guessesText.innerText = `${wrongGuessCount} / ${maxGuesses}`;

    if (wrongGuessCount === maxGuesses) return gameOver(false);
    if (correctLetters.length === currentWord.length) return gameOver(true);
}

for (let i = 45; i <= 122; i++) {
    if (i === 45 || (i > 47 && i < 58)|| (i > 96 && i < 123)) {
        generarletra(i);
    }
}
    function generarletra(i){
        const button = document.createElement("button");
        button.innerText = String.fromCharCode(i);
        keyboardDiv.appendChild(button);
        button.addEventListener("click", (e) => initGame(e.target, String.fromCharCode(i)));
    }

getRandomWord();
playAgainBtn.addEventListener("click", getRandomWord);